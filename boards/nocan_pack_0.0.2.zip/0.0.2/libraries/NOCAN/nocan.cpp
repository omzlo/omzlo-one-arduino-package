#include <stdlib.h>
#include "nocan.h"
#include <avr/wdt.h>
#define reset_mcu() do { wdt_enable(WDTO_15MS); for(;;) {} } while(0)

NocanClass Nocan;

NocanNodeId  NocanClass::open(void) 
{
    if (nocan_ll_init()<0) return NocanClass::ERROR;

    _node_id = nocan_ll_request_node_id();

    if (_node_id<=0)
        return 0;

    if (nocan_ll_sys_filter(_node_id)<0)
    {
        return NocanClass::ERROR;
    }

    return _node_id;
}

int8_t NocanClass::lookupChannel(const char *channel, NocanBitmap *channel_bitmap) const
{
    int8_t status;
    int8_t lookup_success;
    uint8_t channel_len = 0;
    uint8_t bitmap_len;

    while (channel_len<64 && channel[channel_len]!=0) channel_len++;
	
    status = nocan_ll_sys_send(_node_id,LL_SYS_CHANNEL_LOOKUP,0,channel_len,(const uint8_t *)channel);
    if (status<0)      
        return status;

    status = nocan_ll_sys_recv(LL_SYS_CHANNEL_LOOKUP_ACK,(uint8_t *)&lookup_success,&bitmap_len,(uint8_t *)channel_bitmap);
    if (status<0)
        return status;

    if (lookup_success<0 || bitmap_len!=8)
        return NocanClass::ERROR;

    return NocanClass::OK;
}

int8_t NocanClass::registerChannel(const char *channel) const
{
    int8_t status;
    int8_t channel_id;
    uint8_t channel_len = 0;

    while (channel_len<64 && channel[channel_len]!=0) channel_len++;
	
    status = nocan_ll_sys_send(_node_id,LL_SYS_CHANNEL_REGISTER,0,channel_len,(const uint8_t *)channel);
    if (status<0)      
        return status;

    status = nocan_ll_sys_recv(LL_SYS_CHANNEL_REGISTER_ACK,(uint8_t *)&channel_id,NULL,NULL);
    if (status<0)
        return status;

    return channel_id;
}

int8_t NocanClass::unregisterChannel(uint8_t channel_id) const
{
    int8_t status;

    status = nocan_ll_sys_send(_node_id,LL_SYS_CHANNEL_UNREGISTER,channel_id,0,NULL);
    if (status<0)      
        return status;

    status = nocan_ll_sys_recv(LL_SYS_CHANNEL_UNREGISTER_ACK,NULL,NULL,NULL);
    if (status<0)
        return status;

    return NocanClass::OK;
}

int8_t NocanClass::subscribeChannel(const NocanBitmap *channel_bitmap) const
{
    int8_t status;

    status = nocan_ll_sys_send(_node_id,LL_SYS_CHANNEL_SUBSCRIBE,0,8,(uint8_t *)channel_bitmap);

    if (status<0)
        return status;

    return nocan_ll_msg_filter((uint8_t *)channel_bitmap,1);
}

int8_t NocanClass::unsubscribeChannel(const NocanBitmap *channel_bitmap) const
{
    int8_t status;

    status = nocan_ll_sys_send(_node_id,LL_SYS_CHANNEL_UNSUBSCRIBE,0,8,(uint8_t *)channel_bitmap);

    if (status<0)
        return status;

    return nocan_ll_msg_filter((uint8_t *)channel_bitmap,0);
}


uint8_t NocanClass::processSystemMessage(void) const
{
    uint8_t available = nocan_ll_packet_available();
    nocan_packet_t packet;

    if (bit_is_set(available,LL_PACKET_SYS)) {
        if (nocan_ll_packet_recv(LL_BUFFER_SYS,&packet)<0)
            return NocanClass::ERROR;

        switch (packet.u.system.function) {
            case LL_SYS_NODE_PING:
                nocan_ll_sys_send(_node_id,LL_SYS_NODE_PING_ACK,0,0,0);
                break;
            case LL_SYS_NODE_BOOT_REQUEST:
                reset_mcu();
                break;
                /* default: */
                /*  IGNORE PACKET */
        }
    }
    return available;
}


