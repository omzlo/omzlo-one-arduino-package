#ifndef _NOCAN_LL_H_
#define _NOCAN_LL_H_

#include <stdint.h>

typedef struct {
    uint8_t node_id;
    uint8_t flags;
    union {
        struct {
            uint8_t function;
            uint8_t parameter;
        } system;
        struct {
            uint8_t reserved;
            uint8_t channel_id;
        } message;
    } u;
    uint8_t dlen;
    uint8_t data[8];
} nocan_packet_t;

#define LL_FLAG_FIRST_PACKET        7
#define LL_FLAG_LAST_PACKET         6
#define LL_FLAG_SYSBIT              0

#define LL_SYS_ANY                      0
#define LL_SYS_ADDRESS_REQUEST          1
#define LL_SYS_ADDRESS_CONFIGURE        2
#define LL_SYS_ADDRESS_CONFIGURE_ACK    3
#define LL_SYS_ADDRESS_LOOKUP           4
#define LL_SYS_ADDRESS_LOOKUP_ACK       5
#define LL_SYS_NODE_BOOT_REQUEST        6
#define LL_SYS_NODE_BOOT_ACK            7
#define LL_SYS_NODE_PING                8
#define LL_SYS_NODE_PING_ACK            9

#define LL_SYS_CHANNEL_REGISTER           10
#define LL_SYS_CHANNEL_REGISTER_ACK       11
#define LL_SYS_CHANNEL_UNREGISTER         12
#define LL_SYS_CHANNEL_UNREGISTER_ACK     13

#define LL_SYS_CHANNEL_SUBSCRIBE          14
#define LL_SYS_CHANNEL_UNSUBSCRIBE        15
#define LL_SYS_CHANNEL_LOOKUP             16
#define LL_SYS_CHANNEL_LOOKUP_ACK         17

#define LL_SYS_BOOTLOADER_GET_SIGNATURE		18
#define LL_SYS_BOOTLOADER_GET_SIGNATURE_ACK	19
#define LL_SYS_BOOTLOADER_SET_ADDRESS		20
#define LL_SYS_BOOTLOADER_SET_ADDRESS_ACK	21
#define LL_SYS_BOOTLOADER_WRITE			22
#define LL_SYS_BOOTLOADER_WRITE_ACK		23
#define LL_SYS_BOOTLOADER_READ			24
#define LL_SYS_BOOTLOADER_READ_ACK		25
#define LL_SYS_BOOTLOADER_LEAVE			26
#define LL_SYS_BOOTLOADER_LEAVE_ACK		27

#define NOCAN_LL_OK         0
#define NOCAN_LL_ERROR      (-1)
#define NOCAN_LL_TIMEOUT    (-2)

int8_t nocan_ll_init(void);

int8_t nocan_ll_request_node_id(void);

int8_t nocan_ll_sys_send(int8_t node_id, uint8_t function, uint8_t param, uint8_t dlen, const uint8_t *data);

int8_t nocan_ll_sys_recv(uint8_t function, uint8_t *param, uint8_t *len, uint8_t *data);

int8_t nocan_ll_msg_send(int8_t node_id, uint8_t channel_id, uint8_t len, const uint8_t *data);

int8_t nocan_ll_packet_recv(uint8_t rxbuffer, nocan_packet_t *packet);
#define LL_BUFFER_SYS   0
#define LL_BUFFER_MSG   1

int8_t nocan_ll_msg_filter(const uint8_t channel_bitmap[8], uint8_t enable);

int8_t nocan_ll_sys_filter(int8_t node_id);

uint8_t nocan_ll_packet_available(void);
#define LL_PACKET_SYS   0
#define LL_PACKET_MSG   1

uint8_t nocan_ll_status(void);

int8_t nocan_ll_get_udid(uint8_t dest[8]);

#endif
