#include "spi.h"
#include "mcp2515.h"

MCP2515Class MCP2515;

void MCP2515Class::registerWrite(uint8_t reg, uint8_t val)
{
    SPI.beginTransaction(_spisettings);
    mcp2515_slave_select();
    SPI.transfer(MCP_WRITE);
    SPI.transfer(reg);
    SPI.transfer(val);
    mcp2515_slave_release();
    SPI.endTransaction();
}

void MCP2515Class::registerModify(uint8_t reg, uint8_t mask, uint8_t val)
{
    SPI.beginTransaction(_spisettings);
    mcp2515_slave_select();
    SPI.transfer(MCP_BIT_MODIFY);
    SPI.transfer(reg);
    SPI.transfer(mask);
    SPI.transfer(val);
    mcp2515_slave_release();
    SPI.endTransaction();
}

uint8_t MCP2515Class::registerRead(uint8_t reg)
{
    SPI.beginTransaction(_spisettings);
    mcp2515_slave_select();
    SPI.transfer(MCP_READ);
    SPI.transfer(reg);
    uint8_t retval = SPI.transfer(0);
    mcp2515_slave_release();
    SPI.endTransaction();
    return retval;
}

/*
uint8_t MCP2515Class::rx_status(void)
{
    SPI.beginTransaction(_spisettings);
    mcp2515_slave_select();
    SPI.transfer(MCP_RX_STATUS);
    uint8_t retval = SPI.transfer(0);
    mcp2515_slave_release();
    SPI.endTransaction();
    return retval;
}
*/

uint8_t MCP2515Class::status(void)
{
    SPI.beginTransaction(_spisettings);
    mcp2515_slave_select();
    SPI.transfer(MCP_READ_STATUS);
    uint8_t retval = SPI.transfer(0);
    mcp2515_slave_release();
    SPI.endTransaction();
    return retval;
}


