#ifndef _MCP2515_H_
#define _MCP2515_H_

#include <stdint.h>
#include <SPI.h>

#include <avr/io.h>
#include <stdint.h>
#include "mcp2515def.h"

class MCP2515Class {
    public:
        void begin() { SPI.begin(); mcp2515_slave_setup(); }

        void end() { SPI.end(); }

        void select() { SPI.beginTransaction(SPISettings()); mcp2515_slave_select(); }

        void release() { SPI.endTransaction(); mcp2515_slave_release(); }

        uint8_t status(void);

        void registerWrite(uint8_t reg, uint8_t val);

        void registerModify(uint8_t reg, uint8_t mask, uint8_t val);

        uint8_t registerRead(uint8_t reg);

        int dataAvailable(void) { return bit_is_clear(PINE,SPI_SS_INT); }

        MCP2515Class() : _spisettings() {}
    private:
        SPISettings _spisettings;
};

#define MSG_WAIT_MORE 3

#define MCP_OK 0
#define MCP_FAIL -1

extern MCP2515Class MCP2515;

#endif 
