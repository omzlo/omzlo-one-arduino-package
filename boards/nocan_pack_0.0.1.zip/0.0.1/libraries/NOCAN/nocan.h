#ifndef _NOCAN_H_
#define _NOCAN_H_

#include <stdint.h>
#include <avr/io.h>
#include <nocan_ll.h>

/*
    EID format used:
    pos size    description
    ------------------------
    0   1       first_packet_flag   (0=>not the fist packet in a block, 1=> is the first packet)
    1   7       node_id      
    8   1       last_packet_flag    (0=>not the last packet in a block, 1=> is not the last packet)
    9   1       reserved 
    10  1       sys_flag

    -- if sys_flag == 0 then
    11  2       bank             (4 banks -> 0,1,2,3)
    13  16      channel_bit_map    (4 banks x 16 bits == 64 channels max)

    -- if sys_flag == 1 then
    11  2       reserved
    13  8       function
    21  8       parameter
       
    ------------------------
    29  -       total length
*/ 


#define BUFFER_MAX_AGE 0xFF

typedef int8_t NocanNodeId;

template<uint8_t BSIZE=64> 
struct NocanBuffer {
    uint8_t age;
    NocanNodeId node_id;
    uint8_t channel_id;
    uint8_t length;
    uint8_t data[BSIZE];

    void clear() {
        age = BUFFER_MAX_AGE;
        length = 0;
    }
    bool isFull() const {
        return length>BSIZE-8;
    }
};

template<uint8_t BCOUNT, uint8_t BSIZE=64> 
class NocanMultiplexer {
    public:
        NocanMultiplexer() { clear(); }
        uint8_t capacity() const {
            return BCOUNT;
        }
        void clear() {
            for (uint8_t i=0;i<BCOUNT;i++) _buffers[i].clear();
        }
        int8_t search(NocanNodeId node_id, uint8_t channel_id) {
            int8_t i;

            /* age all buffers, except empty ones which are marked with age==0 */
            for (i=0;i<BCOUNT;i++)
                if (_buffers[i].age) _buffers[i].age++;

            /* find a buffer that is already working for this node */
            for (i=0;i<BCOUNT;i++)
            {
                if (_buffers[i].age && _buffers[i].node_id==node_id)
                {
                    if (_buffers[i].channel_id==channel_id)
                    {
                        _buffers[i].age = 1;
                        return i;
                    }
                    else // this should not normally happen, but we clean up just in case
                    {
                        _buffers[i].clear();
                    }
                }
            }

            /* else: find any buffer that, either
             * - either is free (age==0), 
             * - or has been there for too long (age>=BUFFER_MAX_AGE).
             */
            for (i=0;i<BCOUNT;i++)
            {
                if (_buffers[i].age==0 || _buffers[i].age>=BUFFER_MAX_AGE) 
                {
                    _buffers[i].age = 1;
                    _buffers[i].node_id = node_id;
                    _buffers[i].channel_id = channel_id;
                    _buffers[i].length = 0;
                    return i;
                }
            }
            return -1;
        }
        const NocanBuffer<BSIZE>& operator[](uint8_t index) const {
            return _buffers[index];
        }
        NocanBuffer<BSIZE>& operator[](uint8_t index) {
            return _buffers[index];
        }
    private:
        NocanBuffer<BSIZE> _buffers[BCOUNT];
};


typedef struct {
    uint8_t bitmap[8];
} NocanBitmap;

class NocanClass {
    public:
        enum {  
            OK = 0,
            ERROR = -1,
            TIMEOUT = -2,
            NO_DATA = -3,
            NO_BUFFER_AVAILABLE = -4,
            SYSTEM_MESSAGE = -32,
            WORKING = -33
        };

        NocanNodeId open(void); 

        int8_t close(void) {            
            /*  TODO: send close sys message */
            return NocanClass::OK;
        }

        int8_t lookupChannel(const char *channel, NocanBitmap *channel_bitmap) const;

        int8_t registerChannel(const char *channel) const;

        int8_t unregisterChannel(uint8_t channel_id) const;

        int8_t subscribeChannel(const NocanBitmap *channel_bitmap) const;

        int8_t lookupAndSubscribeChannel(const char *channel) const { 
            NocanBitmap temp;
            int8_t status = lookupChannel(channel, &temp);
            if (status<0)
                return status;
            return subscribeChannel(&temp);
        }

        int8_t unsubscribeChannel(const NocanBitmap *channel_bitmap) const;

        int8_t publishChannel(uint8_t channelId, uint8_t len, const uint8_t *data) const {
            processSystemMessage();
            return nocan_ll_msg_send(_node_id,channelId,len,data);
        }

        template <uint8_t BCOUNT, uint8_t BSIZE>
        int8_t processMessage(NocanMultiplexer<BCOUNT,BSIZE> &mux) const
        {
            uint8_t available = processSystemMessage();

            if (bit_is_set(available,LL_PACKET_MSG))
            {
                int8_t bindex,i,pos;
                nocan_packet_t packet;

                if (nocan_ll_packet_recv(LL_BUFFER_MSG,&packet)<0)
                    return NocanClass::ERROR;

                bindex = mux.search(packet.node_id, packet.u.message.channel_id);
                if (bindex<0) return NocanClass::NO_BUFFER_AVAILABLE;

                /*  check that we will not overflow the buffer */
                if (mux[bindex].isFull())
                {
                    mux[bindex].clear();
                    return NocanClass::ERROR;
                }

                /*  check that first packet indicator is consistent with empty buffer state */
                if (bit_is_set(packet.flags,LL_FLAG_FIRST_PACKET) && mux[bindex].length>0)
                {
                    mux[bindex].clear();
                    return NocanClass::ERROR;
                }

                for (i=0;i<packet.dlen;i++)
                {
                    pos = mux[bindex].length++;
                    mux[bindex].data[pos]=packet.data[i];
                }

                /*  if the last packet of the buffer is recieved, mark it for release and return its index */
                if (bit_is_set(packet.flags,LL_FLAG_LAST_PACKET))
                {
                    mux[bindex].age = BUFFER_MAX_AGE;
                    return bindex;
                }
                return NocanClass::WORKING;
            }
            return NocanClass::NO_DATA;
        }
        
        int8_t getUniqueDeviceIdentifier(uint8_t dest[8]) const { 
            return nocan_ll_get_udid(dest); 
        }

        int8_t status(void) const { 
            return nocan_ll_status(); 
        }
    private:
        uint8_t processSystemMessage(void) const;
        NocanNodeId _node_id;
};

extern NocanClass Nocan;

#endif
