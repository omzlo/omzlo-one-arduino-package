#include "nocan_ll.h"
#include "mcp2515.h"
#include "spi.h"

#include <util/delay.h>
#include <avr/eeprom.h>

#define MODE_GUARD_DELAY 2

/* EEPROM LAYOUT:
 * Addr: 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 
 * Val:  be ef -- -- -- -- -- NN UU UU UU UU UU UU UU UU
 *
 *      NN: last node id
 * UU...UU: 8 byte UDID 
 *      --: don't care
 */

#define MAGICK_FIRST 0xbe
#define MAGICK_SECOND 0xef
#define EEPROM_UDID_ADDR 8
#define EEPROM_LAST_NID_ADDR 7

#define nocan_eeprom_ok() (eeprom_read_byte((const uint8_t *)0)==MAGICK_FIRST && eeprom_read_byte((const uint8_t *)1)==MAGICK_SECOND)

int8_t nocan_ll_get_udid(uint8_t dest[8])
{
    if (nocan_eeprom_ok())
    {
        eeprom_read_block(dest,(const uint8_t *)EEPROM_UDID_ADDR,8);
        return NOCAN_LL_OK;
    }
    return NOCAN_LL_ERROR;
}


int8_t nocan_ll_init(void)
{
    uint8_t i,j;

    MCP2515.begin();

    MCP2515.select();
    SPI.transfer(MCP_RESET);
    MCP2515.release();

    _delay_ms(100);

    if ((MCP2515.registerRead(CANSTAT)&0xE0)!=0x80)
    {
	    return NOCAN_LL_ERROR;    /*  check if we are in config mode */
    }

    /*  Zero the tx message regsisters for a clean start (this is not necessary, just cosmetic) */
    for (i=TXB0+xSIDH;i<=TXB2+xSIDH;i+=16)
        for (j=0;j<13;j++)
            MCP2515.registerWrite(i+j,0x00);
 
    MCP2515.registerWrite(CNF1,0x03);
    MCP2515.registerWrite(CNF2,0xF0);
    MCP2515.registerWrite(CNF3,0x86);
    
    //MCP2515.registerWrite(RXB0+xCTRL, (1<<RXM0) | (1<<RXM1)); 		// Buffer 0: receive everything + *NO* rollover to next buffer
    //MCP2515.registerWrite(RXB1+xCTRL, (1<<RXM0) | (1<<RXM1));          // Buffer 1: receive everything
    MCP2515.registerWrite(RXB0+xCTRL, (1<<RXM1)); // receive only messages with extended identifier 
    MCP2515.registerWrite(RXB1+xCTRL, (1<<RXM1)); // receive only messages with extended identifier

    /*  set CANINTE.RX0IE to 1, interrupt enable for RX0 */
    MCP2515.registerModify(CANINTE, 1<<RX0IE, 1<<RX0IE);

    /*  set CANINTE.RX1IE to 1, interrupt enable for RX1 */
    MCP2515.registerModify(CANINTE, 1<<RX1IE, 1<<RX1IE);

    /*  Prepare second mask */
    MCP2515.registerWrite(RXM1SIDH,0x00);  /*  don't care */
    MCP2515.registerWrite(RXM1SIDL,0x6B);  /*  0110 1011 */
    MCP2515.registerWrite(RXM1EID8,0xFF);  /*  all bits */
    MCP2515.registerWrite(RXM1EID0,0xFF);  /*  all bits */
    //MCP2515.registerWrite(RXM1SIDH,0xFF); 
    //MCP2515.registerWrite(RXM1SIDL,0xFF); 
    //MCP2515.registerWrite(RXM1EID8,0xFF); 
    //MCP2515.registerWrite(RXM1EID0,0xFF);

    MCP2515.registerWrite(RXF1SIDH,0x00); 
    MCP2515.registerWrite(RXF1SIDL,0x00); 
    MCP2515.registerWrite(RXF1EID8,0x00); 
    MCP2515.registerWrite(RXF1EID0,0x00);

    /*  init filters */
    MCP2515.registerWrite(RXF2SIDH,0x00);  /*  don't care */
    MCP2515.registerWrite(RXF2SIDL,0x08);  /*  bank 0 | EXIDE bit */
    MCP2515.registerWrite(RXF2EID8,0x00);  /*  null bitmap */
    MCP2515.registerWrite(RXF2EID0,0x00);  /*  null bitmap */

    MCP2515.registerWrite(RXF3SIDH,0x00);  /*  don't care */
    MCP2515.registerWrite(RXF3SIDL,0x09);  /*  bank 1 | EXIDE bit */
    MCP2515.registerWrite(RXF3EID8,0x00);  /*  null bitmap */
    MCP2515.registerWrite(RXF3EID0,0x00);  /*  null bitmap */

    MCP2515.registerWrite(RXF4SIDH,0x00);  /*  don't care */
    MCP2515.registerWrite(RXF4SIDL,0x0A);  /*  bank 2 | EXIDE bit */
    MCP2515.registerWrite(RXF4EID8,0x00);  /*  null bitmap */
    MCP2515.registerWrite(RXF4EID0,0x00);  /*  null bitmap */

    MCP2515.registerWrite(RXF5SIDH,0x00);  /*  don't care */
    MCP2515.registerWrite(RXF5SIDL,0x0B);  /*  bank 3 | EXIDE bit */
    MCP2515.registerWrite(RXF5EID8,0x00);  /*  null bitmap */
    MCP2515.registerWrite(RXF5EID0,0x00);  /*  null bitmap */


    return nocan_ll_sys_filter(0);
}

int8_t nocan_ll_request_node_id(void)
{
    int8_t status;
    int8_t node_id;
    uint8_t last_id;
    uint8_t udid_send[8]; 
    uint8_t udid_recv[8];
    uint8_t attempts;
    uint8_t i,rlen;
    //uint8_t rnd = 0;

    if (nocan_ll_get_udid(udid_send)<0)
        return NOCAN_LL_ERROR;

    last_id = eeprom_read_byte((const uint8_t *)EEPROM_LAST_NID_ADDR);

    for (attempts=0;attempts<3;attempts++) 
    {
        status = nocan_ll_sys_send(0,LL_SYS_ADDRESS_REQUEST,last_id,8,udid_send);

        if (status!=0) 
            return status;

        status = nocan_ll_sys_recv(LL_SYS_ADDRESS_CONFIGURE,(uint8_t *)&node_id,&rlen,udid_recv);

        if (status==0 && rlen==8)
        {
            for (i=0;i<8;i++)
                if (udid_send[i]!=udid_recv[i]) break;
            if (i==8) 
            {
                nocan_ll_sys_send(0,LL_SYS_ADDRESS_CONFIGURE_ACK,node_id,0,0);
                eeprom_update_byte((uint8_t *)EEPROM_LAST_NID_ADDR, (uint8_t)node_id);
                return node_id;
            }
        }
        //rnd = udid_send[7] ^ udid_recv[7];
        //while (rnd--) _delay_ms(1);   /*  introduce some random delay cheaply, it doesn't matter that udid_recv is not set */
    }
    return NOCAN_LL_ERROR;
}

int8_t ll_send(uint8_t h1, uint8_t h2, uint8_t h3, uint8_t h4, uint8_t dlen, const uint8_t *data)
{
    uint8_t base,pos,tlen,val;

    pos = 0;
    
    do
    {
        for (;;)
        {
            val = MCP2515.status();

            if (bit_is_clear(val,STATUS_TXB0CNTRL_TXREQ))
            {
                base = TXB0;
                break;
            }
           
            if (bit_is_clear(val, STATUS_TXB1CNTRL_TXREQ))
            {
                base = TXB1;
                break;
            }
            /*
            if (bit_is_clear(val, STATUS_TXB2CNTRL_TXREQ))
            {
                base = TXB2;
                break;
            }
            */
            
            _delay_us(100);
        }

        if (pos==0)
        {
            h1 |= 0x80;     /*  set first_packet_flag */
        }
        else
        {
            h1 &= 0x7F;     /*  clear first_packet_flag */
        }

        if (dlen-pos<=8)
        {
            h2 |= 0x80;     /*  set last_packet_flag */
            tlen = dlen-pos;
        }
        else
        {
            h2 &= 0x7F;     /*  clear last_packet_flag */
            tlen = 8;
        }

        h2 |= 0x08;         /*  extended frame marker */


        MCP2515.select();
        SPI.transfer(MCP_WRITE);
        SPI.transfer(base+xSIDH);
        SPI.transfer(h1);
        SPI.transfer(h2);
        SPI.transfer(h3);
        SPI.transfer(h4);

        SPI.transfer(tlen);
        while (tlen--) 
        {
            SPI.transfer(*data++);
            pos++;
        }
        MCP2515.release();

        MCP2515.registerModify(base+xCTRL,1<<TXREQ,1<<TXREQ);
    }
    while (pos<dlen);
 
    return NOCAN_LL_OK;
}

int8_t nocan_ll_sys_send(int8_t node_id, uint8_t function, uint8_t param, uint8_t dlen, const uint8_t *data)
{
    return ll_send(node_id,0x20,function,param,dlen,data);
}

int8_t nocan_ll_sys_recv(uint8_t function, uint8_t *param, uint8_t *len, uint8_t *data)
{
    /*  We will assume for simplicity that recieved sys messages are composed of one packet */
    /*  TODO: extend for multipacket */

    nocan_packet_t packet;
    uint16_t delay = 0;
    uint8_t i;

    for (;;)
    {
        while ((nocan_ll_packet_available() & (1<<LL_PACKET_SYS))==0) // bit_is_set can't be used here
        { 
            _delay_ms(1); 
            if (delay++>1000) return NOCAN_LL_TIMEOUT;
        }

        nocan_ll_packet_recv(LL_BUFFER_SYS,&packet);
        if (/*bit_is_set(packet.flags,LL_FLAG_SYSBIT) && */packet.u.system.function==function)
        {
            if (param)
                *param = packet.u.system.parameter;
            if (len)
                *len = packet.dlen;
            if (data)
            {
                for (i=0;i<packet.dlen;i++)
                    data[i] = packet.data[i];    
            }
            return NOCAN_LL_OK;
        }
    }
    return NOCAN_LL_TIMEOUT; // never get here
}

int8_t nocan_ll_msg_send(int8_t node_id, uint8_t channel_id, uint8_t len, const uint8_t *data)
{
    uint8_t bank = channel_id>>4;
    uint16_t bitmap = ((uint16_t)1)<<(channel_id&0xF);

    return ll_send(node_id,bank,bitmap>>8,bitmap&0xFF,len,data);
}

uint8_t ctz(uint16_t c)
{
    uint8_t r = 0;
    if (c==0) return 16;
    if ((c&0x00FF)==0)
    {
        r+=8;
        c>>=8;
    }
    if ((c&0x000F)==0)
    {
        r+=4;
        c>>=4;
    }
    if ((c&0x0003)==0)
    {
        r+=2;
        c>>=2;
    }
    if ((c&0x0001)==0)
    {
        r+=1;
    }
    return r;
}

int8_t nocan_ll_packet_recv(uint8_t rxbuffer, nocan_packet_t *packet)
{
    uint8_t base,a,clear,retval;

    if (rxbuffer==LL_BUFFER_SYS)
    {
        base = RXB0;
        clear = 1<<RX0IF;
    } 
    else if (rxbuffer==LL_BUFFER_MSG) 
    {
        base = RXB1;
        clear = 1<<RX1IF;
    }
    else
    {
	return NOCAN_LL_ERROR;
    }


    retval = NOCAN_LL_ERROR;

    MCP2515.select();
    SPI.transfer(MCP_READ);
    SPI.transfer(base+xSIDH);
    a = SPI.transfer(0);
    packet->flags = a&0x80;         /*  first_packet_flag (LL_FLAG_FIRST_PACKET -> 1<<7) */
    packet->node_id = a&0x7F;
    
    a = SPI.transfer(0);

    /*  bits of a here:
        a_7 -> last_packet_flag
        a_6 -> n/a
        a_5 -> sysbit
        a_4 -> n/a
        a_3 -> extended frame identifier
        a_2 -> n/a
        a_1 -> bank msb
        a_1 -> bank lsb
    */

    if (bit_is_clear(a,3))          /*  check if is extended address, issue error otherwise */
        goto leave_function;

    packet->flags |= (a&0x80)>>1;   /*  last_packet_flag */

    if (bit_is_set(a,5)) 
    {
        packet->flags |= 1;         /*  sysbit flag */

        a = SPI.transfer(0);
        packet->u.system.function = a;
        a = SPI.transfer(0);
        packet->u.system.parameter = a;
    }
    else
    {
        uint16_t bitmap;
        
        bitmap = SPI.transfer(0);
        bitmap <<= 8; 
        bitmap |= SPI.transfer(0);
        if ((packet->u.message.channel_id = ctz(bitmap))==16)   /*  ctz returns the number of tailing zeros or 16 if bitmap==0 */
            goto leave_function; 
        packet->u.message.channel_id |= ((a&3)<<4);
    }
        
 
    a = SPI.transfer(0);
    packet->dlen = a&0xF;   /*  remove top 4 bits */

    for (a=0;a<packet->dlen;a++)
    {
        packet->data[a] = SPI.transfer(0);
    }

    retval = NOCAN_LL_OK;

leave_function:
    MCP2515.release();
 
    MCP2515.registerModify(CANINTF,clear,0);

    return retval;
}

int8_t ll_mode_select(uint8_t mode)
{
    MCP2515.registerModify(CANCTRL,0xE0,mode); // 3 upper bits
    
    _delay_ms(MODE_GUARD_DELAY);

    return ((MCP2515.registerRead(CANSTAT)&0xE0)==mode);
}

// TODO: Make it progmem
const uint8_t FILTER_REGS[8] = { RXF5EID8, RXF5EID0, RXF4EID8, RXF4EID0, RXF3EID8, RXF3EID0, RXF2EID8, RXF2EID0 };

int8_t nocan_ll_msg_filter(const uint8_t channel_bitmap[8], uint8_t enable)
{
    uint8_t reg,filter,i;

    if (!ll_mode_select(0x80)) 
        return NOCAN_LL_ERROR;
    //register_dump();

    for (i=0;i<8;i++)
    {
        reg = FILTER_REGS[i];
        filter = MCP2515.registerRead(reg);
        if (enable) 
            filter |= channel_bitmap[i];
        else
            filter &= ~channel_bitmap[i];
        MCP2515.registerWrite(reg, filter);
    }

    //register_dump();
    if (!ll_mode_select(0x00)) return NOCAN_LL_ERROR;

    return NOCAN_LL_OK;
}

int8_t nocan_ll_sys_filter(int8_t node_id)
{
    if (!ll_mode_select(0x80)) return NOCAN_LL_ERROR;
    
    MCP2515.registerWrite(RXM0SIDH,0x7F);
    MCP2515.registerWrite(RXM0SIDL,0x68);  /*  0110 1000 */
    MCP2515.registerWrite(RXM0EID8,0x00);  /*  don't care */
    MCP2515.registerWrite(RXM0EID0,0x00);  /*  don't care */

    MCP2515.registerWrite(RXF0SIDH,node_id);
    MCP2515.registerWrite(RXF0SIDL,0x28);  /*  0010 1000 */
    MCP2515.registerWrite(RXF0EID8,0x00);  /*  don't care */
    MCP2515.registerWrite(RXF0EID0,0x00);  /*  don't care */

    if (!ll_mode_select(0x00)) return NOCAN_LL_ERROR;

    return NOCAN_LL_OK;
}

uint8_t nocan_ll_packet_available(void)
{
    if (MCP2515.dataAvailable())
    {
    	return MCP2515.status()&0x03;
    }
    return 0;
}

uint8_t nocan_ll_status(void)
{
	return MCP2515.status();
}
